import os
import time
import json
import datetime
import numpy as np
import pandas as pd
import cv2
import streamlit as st
from PIL import Image

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

st.set_page_config(page_title="EcoVision Materials AI", page_icon="♻️", layout="wide")

MODEL_PATH = "ecovision_material_model.keras"
CLASS_NAMES_PATH = "class_names.txt"
FEEDBACK_CSV = "user_feedback_v3.csv"
MODEL_REPORT_PATH = "model_report.json"
IMG_SIZE = 224

DEFAULT_CLASSES = ["cardboard", "glass", "metal", "paper", "plastic", "trash"]
CARBON_FACTORS = {
    "plastic": 0.12,
    "paper": 0.08,
    "metal": 0.25,
    "glass": 0.05,
    "cardboard": 0.07,
    "trash": 0.00,
}

MATERIAL_INSIGHTS = {
    "plastic": {
        "ko": "플라스틱",
        "property": "가볍고 성형성이 좋지만 종류별 재활용성이 크게 다릅니다.",
        "recycle": "PET/HDPE/PP 등 세부 수지 구분 기능을 추가하면 신소재·자원순환 연구성이 크게 올라갑니다.",
        "material_link": "재생 플라스틱 펠릿, 경량 복합재, 3D 프린팅 필라멘트 후보 분석으로 확장 가능",
    },
    "metal": {
        "ko": "금속",
        "property": "강도와 전기·열전도성이 높고 재활용 효율이 좋은 소재군입니다.",
        "recycle": "알루미늄/철/스테인리스 분류로 확장하면 항공우주용 경량 합금 탐구와 연결됩니다.",
        "material_link": "경량 합금, 재생 알루미늄, 고강도 구조재 후보 분석으로 확장 가능",
    },
    "glass": {
        "ko": "유리",
        "property": "화학적 안정성과 투명성이 높지만 파손 위험과 색상별 재활용 차이가 있습니다.",
        "recycle": "색상·오염도·파손 여부를 분류하면 재활용 품질 예측 연구로 발전할 수 있습니다.",
        "material_link": "유리 섬유, 단열재, 재생 유리 소재 활용 분석으로 확장 가능",
    },
    "paper": {
        "ko": "종이",
        "property": "섬유 기반 소재로 재활용이 쉽지만 수분과 오염에 취약합니다.",
        "recycle": "오염도와 코팅 여부를 판단하면 재생섬유 품질 예측 기능으로 확장됩니다.",
        "material_link": "친환경 포장재, 셀룰로오스 기반 바이오소재 분석으로 확장 가능",
    },
    "cardboard": {
        "ko": "골판지",
        "property": "충격 흡수와 경량성이 좋아 포장재로 널리 쓰이는 섬유 기반 소재입니다.",
        "recycle": "습기·압착·오염 상태를 추가 판단하면 재사용 가능성 평가가 가능합니다.",
        "material_link": "재생 포장재, 완충 구조재, 셀룰로오스 복합소재 연구로 확장 가능",
    },
    "trash": {
        "ko": "일반폐기물",
        "property": "재활용 가치가 낮거나 오염되어 선별 공정에서 제외될 가능성이 높은 항목입니다.",
        "recycle": "왜 재활용 불가인지 사유를 설명하는 기능을 넣으면 교육성과 실용성이 올라갑니다.",
        "material_link": "오염도 판단, 소각/매립 저감, 대체 소재 추천 기능으로 확장 가능",
    },
}


def load_class_names():
    if os.path.exists(CLASS_NAMES_PATH):
        with open(CLASS_NAMES_PATH, "r", encoding="utf-8") as f:
            names = [line.strip() for line in f if line.strip()]
        return names if names else DEFAULT_CLASSES
    return DEFAULT_CLASSES

TARGET_CLASSES = load_class_names()

@st.cache_resource(show_spinner=False)
def load_model():
    if not os.path.exists(MODEL_PATH):
        return None, "모델 파일이 없습니다. train_pipeline_v2.py로 학습 후 ecovision_material_model.keras를 업로드하세요."
    try:
        import tensorflow as tf
        return tf.keras.models.load_model(MODEL_PATH), None
    except Exception as e:
        return None, f"모델 로드 실패: {e}"

model, model_error = load_model()


def load_model_report():
    if os.path.exists(MODEL_REPORT_PATH):
        try:
            with open(MODEL_REPORT_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None
    return None


def get_system_analytics(report):
    feedback_count = 0
    feedback_accuracy = None
    if os.path.exists(FEEDBACK_CSV):
        try:
            df = pd.read_csv(FEEDBACK_CSV)
            feedback_count = len(df)
            if feedback_count > 0 and "is_correct" in df.columns:
                feedback_accuracy = round(df["is_correct"].mean() * 100, 1)
        except Exception:
            pass

    validation_accuracy = None
    if report and "best_val_accuracy" in report:
        validation_accuracy = round(float(report["best_val_accuracy"]) * 100, 1)

    displayed_accuracy = validation_accuracy if validation_accuracy is not None else feedback_accuracy
    return feedback_count, feedback_accuracy, validation_accuracy, displayed_accuracy


def preprocess_for_mobilenet(pil_img):
    import tensorflow as tf
    resized = pil_img.convert("RGB").resize((IMG_SIZE, IMG_SIZE))
    arr = tf.keras.utils.img_to_array(resized)
    arr = np.expand_dims(arr, axis=0)
    arr = tf.keras.applications.mobilenet_v2.preprocess_input(arr)
    return arr, np.array(resized)


def find_last_conv_layer(m):
    import tensorflow as tf
    # model.submodules includes nested MobileNetV2 layers in most TF/Keras versions.
    for layer in reversed(list(m.submodules)):
        if isinstance(layer, tf.keras.layers.Conv2D):
            return layer.name
    return None


def make_gradcam_heatmap(img_array, m, pred_index=None):
    import tensorflow as tf
    last_conv_name = find_last_conv_layer(m)
    if last_conv_name is None:
        raise ValueError("Conv2D 레이어를 찾을 수 없습니다.")

    last_conv_layer = None
    for layer in m.submodules:
        if layer.name == last_conv_name:
            last_conv_layer = layer
            break
    if last_conv_layer is None:
        raise ValueError("마지막 Conv2D 레이어 연결에 실패했습니다.")

    grad_model = tf.keras.models.Model(m.inputs, [last_conv_layer.output, m.output])
    with tf.GradientTape() as tape:
        conv_outputs, predictions = grad_model(img_array)
        if pred_index is None:
            pred_index = tf.argmax(predictions[0])
        class_channel = predictions[:, pred_index]

    grads = tape.gradient(class_channel, conv_outputs)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))
    conv_outputs = conv_outputs[0]
    heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)
    heatmap = tf.maximum(heatmap, 0) / (tf.reduce_max(heatmap) + 1e-8)
    return heatmap.numpy(), last_conv_name


def overlay_heatmap(original_rgb, heatmap, alpha=0.38):
    heatmap = cv2.resize(heatmap, (original_rgb.shape[1], original_rgb.shape[0]))
    heatmap = np.uint8(255 * heatmap)
    heatmap_color = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
    heatmap_color = cv2.cvtColor(heatmap_color, cv2.COLOR_BGR2RGB)
    return cv2.addWeighted(original_rgb, 1 - alpha, heatmap_color, alpha, 0)


def edge_fallback(original_rgb):
    gray = cv2.cvtColor(original_rgb, cv2.COLOR_RGB2GRAY)
    grad_x = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    magnitude = cv2.magnitude(grad_x, grad_y)
    magnitude = cv2.GaussianBlur(magnitude, (15, 15), 0)
    magnitude = (magnitude / (magnitude.max() + 1e-8) * 255).astype(np.uint8)
    heatmap = cv2.applyColorMap(magnitude, cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    return cv2.addWeighted(original_rgb, 0.62, heatmap, 0.38, 0)


def predict_image(pil_img):
    if model is None:
        raise RuntimeError(model_error or "모델이 준비되지 않았습니다.")
    img_array, original_rgb = preprocess_for_mobilenet(pil_img)
    preds = model.predict(img_array, verbose=0)[0]
    top_indices = np.argsort(preds)[::-1][:3]
    top_idx = int(top_indices[0])
    predicted_class = TARGET_CLASSES[top_idx] if top_idx < len(TARGET_CLASSES) else str(top_idx)
    confidence = float(preds[top_idx] * 100)

    xai_mode = "Grad-CAM"
    layer_name = None
    try:
        heatmap, layer_name = make_gradcam_heatmap(img_array, model, top_idx)
        xai_img = overlay_heatmap(original_rgb, heatmap)
    except Exception as e:
        xai_mode = f"Edge fallback: {e}"
        xai_img = edge_fallback(original_rgb)

    top3 = []
    for idx in top_indices:
        label = TARGET_CLASSES[int(idx)] if int(idx) < len(TARGET_CLASSES) else str(int(idx))
        top3.append({"class": label, "confidence": round(float(preds[int(idx)] * 100), 2)})
    return predicted_class, confidence, top3, xai_img, xai_mode, layer_name


def save_feedback(filename, predicted, confidence, actual):
    row = {
        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "filename": filename,
        "predicted": predicted,
        "confidence": round(confidence, 2),
        "actual": actual,
        "is_correct": predicted == actual,
    }
    df = pd.DataFrame([row])
    if not os.path.exists(FEEDBACK_CSV):
        df.to_csv(FEEDBACK_CSV, index=False, encoding="utf-8-sig")
    else:
        df.to_csv(FEEDBACK_CSV, mode="a", header=False, index=False, encoding="utf-8-sig")


def material_card(label):
    item = MATERIAL_INSIGHTS.get(label, MATERIAL_INSIGHTS["trash"])
    st.markdown(f"### 🔬 신소재·자원순환 해석: {item['ko']}")
    st.write(f"**소재 특성:** {item['property']}")
    st.write(f"**고도화 방향:** {item['recycle']}")
    st.write(f"**신소재 연계:** {item['material_link']}")


report = load_model_report()
feedback_count, feedback_acc, validation_acc, displayed_acc = get_system_analytics(report)

st.markdown("""
<style>
.main { background-color: #f8f9fa; }
div[data-testid="stMetricValue"] { color: #2e7d32; font-weight: 800; font-size: 2.0rem; }
.report-card { background-color: #ffffff; padding: 22px; border-radius: 14px; box-shadow: 0 6px 16px rgba(0,0,0,0.05); margin-bottom: 18px; }
.small-note { color: #666; font-size: 0.92rem; }
</style>
""", unsafe_allow_html=True)

st.title("♻️ EcoVision Materials AI")
st.caption("재활용 이미지 분류 + 실제 모델 검증 + Grad-CAM 기반 설명가능 AI + 신소재 확장 분석")

if model is None:
    st.warning(model_error)
else:
    st.success("모델이 정상 로드되었습니다. 실제 예측만 수행하며 랜덤 예측은 사용하지 않습니다.")

m1, m2, m3, m4 = st.columns(4)
m1.metric("검증 정확도", f"{validation_acc}%" if validation_acc is not None else "리포트 없음")
m2.metric("사용자 피드백 정확도", f"{feedback_acc}%" if feedback_acc is not None else "데이터 없음")
m3.metric("피드백 누적", f"{feedback_count}건")
m4.metric("클래스 수", f"{len(TARGET_CLASSES)}개")

with st.expander("📌 심사용 핵심 개선 포인트"):
    st.write("- 모델 파일이 없을 때 랜덤 예측을 하지 않고 오류를 명확히 표시합니다.")
    st.write("- CNN 마지막 Conv2D 레이어 기준 Grad-CAM을 먼저 시도하고, 실패 시 대체 시각화임을 표시합니다.")
    st.write("- train_pipeline_v2.py가 저장한 model_report.json을 읽어 검증 정확도와 클래스별 성능을 표시합니다.")
    st.write("- 예측 결과를 신소재·재활용 소재 활용 방향과 연결합니다.")

left, right = st.columns([1, 1])

with left:
    st.markdown("<div class='report-card'>", unsafe_allow_html=True)
    st.subheader("📸 이미지 업로드")
    uploaded_file = st.file_uploader("분류할 재활용품 이미지를 업로드하세요.", type=["png", "jpg", "jpeg"])
    if uploaded_file:
        img = Image.open(uploaded_file).convert("RGB")
        st.image(img, caption="업로드 이미지", use_container_width=True)
        run = st.button("🚀 실제 AI 추론 실행", use_container_width=True, type="primary", disabled=(model is None))
    else:
        img = None
        run = False
    st.markdown("</div>", unsafe_allow_html=True)

with right:
    st.markdown("<div class='report-card'>", unsafe_allow_html=True)
    st.subheader("🎯 예측 결과와 XAI")
    if run and img is not None:
        try:
            start = time.time()
            predicted, confidence, top3, xai_img, xai_mode, layer_name = predict_image(img)
            latency = round((time.time() - start) * 1000, 1)
            carbon = CARBON_FACTORS.get(predicted, 0.0)

            c1, c2, c3 = st.columns(3)
            c1.metric("예측 클래스", predicted.upper())
            c2.metric("신뢰도", f"{confidence:.2f}%")
            c3.metric("추론 시간", f"{latency} ms")

            st.image(xai_img, caption=f"XAI 시각화: {xai_mode}" + (f" / layer={layer_name}" if layer_name else ""), use_container_width=True)
            st.write("#### Top-3 예측")
            st.dataframe(pd.DataFrame(top3), use_container_width=True)
            st.info(f"예상 탄소 저감 계수: {carbon} kgCO₂e/unit")

            material_card(predicted)

            st.divider()
            st.write("#### Active Learning 피드백")
            final_label = st.selectbox("실제 정답 레이블", TARGET_CLASSES, index=TARGET_CLASSES.index(predicted) if predicted in TARGET_CLASSES else 0)
            if st.button("피드백 저장", use_container_width=True):
                save_feedback(uploaded_file.name, predicted, confidence, final_label)
                st.success("피드백이 저장되었습니다. 다음 재학습 데이터로 사용할 수 있습니다.")
        except Exception as e:
            st.error(f"추론 실패: {e}")
    else:
        st.info("이미지를 업로드하고 추론을 실행하면 결과가 표시됩니다.")
    st.markdown("</div>", unsafe_allow_html=True)

if report:
    st.markdown("<div class='report-card'>", unsafe_allow_html=True)
    st.subheader("📊 모델 검증 리포트")
    r1, r2, r3 = st.columns(3)
    r1.metric("Best Val Accuracy", f"{float(report.get('best_val_accuracy', 0))*100:.2f}%")
    r2.metric("Final Val Accuracy", f"{float(report.get('final_val_accuracy', 0))*100:.2f}%")
    r3.metric("학습 클래스", ", ".join(report.get("class_names", TARGET_CLASSES)))

    if "per_class_accuracy" in report:
        st.write("#### 클래스별 검증 정확도")
        df_acc = pd.DataFrame([
            {"class": k, "accuracy": round(v * 100, 2)} for k, v in report["per_class_accuracy"].items()
        ])
        st.dataframe(df_acc, use_container_width=True)

    if "confusion_matrix" in report:
        st.write("#### Confusion Matrix")
        cm = pd.DataFrame(report["confusion_matrix"], index=report.get("class_names", TARGET_CLASSES), columns=report.get("class_names", TARGET_CLASSES))
        st.dataframe(cm, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)
else:
    st.info("model_report.json이 있으면 검증 정확도, 클래스별 성능, confusion matrix가 자동 표시됩니다.")
