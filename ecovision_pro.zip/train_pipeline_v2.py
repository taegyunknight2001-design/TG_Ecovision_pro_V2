import os
import json
import numpy as np
import tensorflow as tf
import keras
from keras import layers
from keras.applications import MobileNetV2

IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS_HEAD = 5
EPOCHS_FINE = 15
DATASET_DIR = "dataset"
MODEL_NAME = "ecovision_material_model.keras"
REPORT_NAME = "model_report.json"

REQUIRED_CLASSES = ["cardboard", "glass", "metal", "paper", "plastic", "trash"]

if not os.path.exists(DATASET_DIR):
    os.makedirs(DATASET_DIR, exist_ok=True)
    for cat in REQUIRED_CLASSES:
        os.makedirs(os.path.join(DATASET_DIR, cat), exist_ok=True)
    print(f"'{DATASET_DIR}' 폴더를 만들었습니다. 각 클래스 폴더에 이미지를 넣고 다시 실행하세요.")
    raise SystemExit(0)

train_ds = keras.utils.image_dataset_from_directory(
    DATASET_DIR,
    validation_split=0.2,
    subset="training",
    seed=123,
    image_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    label_mode="int",
)
val_ds = keras.utils.image_dataset_from_directory(
    DATASET_DIR,
    validation_split=0.2,
    subset="validation",
    seed=123,
    image_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    label_mode="int",
    shuffle=False,
)

class_names = train_ds.class_names
with open("class_names.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(class_names))
print("class_names:", class_names)

AUTOTUNE = tf.data.AUTOTUNE
train_ds = train_ds.prefetch(AUTOTUNE)
val_ds = val_ds.prefetch(AUTOTUNE)

data_augmentation = keras.Sequential([
    layers.RandomFlip("horizontal"),
    layers.RandomRotation(0.15),
    layers.RandomZoom(0.12),
    layers.RandomContrast(0.12),
], name="data_augmentation")

base_model = MobileNetV2(
    input_shape=(IMG_SIZE, IMG_SIZE, 3),
    include_top=False,
    weights="imagenet",
    name="mobilenetv2_backbone",
)
base_model.trainable = False

inputs = keras.Input(shape=(IMG_SIZE, IMG_SIZE, 3), name="image")
x = data_augmentation(inputs)
x = layers.Lambda(lambda img: tf.keras.applications.mobilenet_v2.preprocess_input(img), name="mobilenet_preprocess")(x)
x = base_model(x, training=False)
x = layers.GlobalAveragePooling2D(name="global_average_pooling")(x)
x = layers.Dropout(0.35, name="dropout")(x)
outputs = layers.Dense(len(class_names), activation="softmax", name="material_classifier")(x)
model = keras.Model(inputs, outputs, name="ecovision_material_classifier")

callbacks = [
    keras.callbacks.EarlyStopping(monitor="val_loss", patience=4, restore_best_weights=True),
    keras.callbacks.ModelCheckpoint(MODEL_NAME, monitor="val_accuracy", save_best_only=True),
    keras.callbacks.CSVLogger("training_log.csv"),
]

model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=1e-3),
    loss=keras.losses.SparseCategoricalCrossentropy(),
    metrics=["accuracy"],
)
print("[Phase 1] 분류 헤드 학습 시작")
h1 = model.fit(train_ds, validation_data=val_ds, epochs=EPOCHS_HEAD, callbacks=callbacks)

base_model.trainable = True
for layer in base_model.layers[:100]:
    layer.trainable = False

model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=1e-5),
    loss=keras.losses.SparseCategoricalCrossentropy(),
    metrics=["accuracy"],
)
print("[Phase 2] MobileNetV2 일부 미세조정 시작")
h2 = model.fit(train_ds, validation_data=val_ds, epochs=EPOCHS_FINE, callbacks=callbacks)

# Best checkpoint reload for reliable report
if os.path.exists(MODEL_NAME):
    model = keras.models.load_model(MODEL_NAME)

val_loss, val_acc = model.evaluate(val_ds, verbose=0)

y_true = []
y_pred = []
for images, labels in val_ds:
    probs = model.predict(images, verbose=0)
    y_true.extend(labels.numpy().tolist())
    y_pred.extend(np.argmax(probs, axis=1).tolist())

y_true = np.array(y_true, dtype=int)
y_pred = np.array(y_pred, dtype=int)
num_classes = len(class_names)
cm = tf.math.confusion_matrix(y_true, y_pred, num_classes=num_classes).numpy().tolist()

per_class_accuracy = {}
cm_np = np.array(cm)
for i, name in enumerate(class_names):
    total = int(cm_np[i].sum())
    correct = int(cm_np[i, i])
    per_class_accuracy[name] = float(correct / total) if total > 0 else 0.0

all_val_acc = []
for h in (h1, h2):
    all_val_acc.extend(h.history.get("val_accuracy", []))

report = {
    "class_names": class_names,
    "best_val_accuracy": float(max(all_val_acc)) if all_val_acc else float(val_acc),
    "final_val_accuracy": float(val_acc),
    "final_val_loss": float(val_loss),
    "confusion_matrix": cm,
    "per_class_accuracy": per_class_accuracy,
    "image_size": IMG_SIZE,
    "batch_size": BATCH_SIZE,
    "model": "MobileNetV2 transfer learning + fine tuning",
}

with open(REPORT_NAME, "w", encoding="utf-8") as f:
    json.dump(report, f, ensure_ascii=False, indent=2)

print(f"모델 저장 완료: {MODEL_NAME}")
print(f"검증 리포트 저장 완료: {REPORT_NAME}")
print(json.dumps(report, ensure_ascii=False, indent=2))
